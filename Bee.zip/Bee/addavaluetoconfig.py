#!/usr/bin/python3

import pickle

print("Du kannst nun einen Wert zur bee.cfg hinzufügen")

part  = str(input("Name des Wertes: "))
value = str(input("Inhalt: "))
try:
	entry = pickle.load(open("bee.conf", "rb"))
	print(entry)
except:
	print("Almost empty")
		
entry[part] = value
print(entry)

pickle.dump(entry,open("bee.conf", "wb"))



print("Done")
