#!/usr/bin/python3

# V1.1			Andreas Lanzl			05. Apr. 2021
# In diesem Skript sollen die Sensoren ausgelesen und die erhaltenen Daten
# in eine SQLite-DB geschrieben werden.

# Klassen und Module importieren

import classes
import waage as bl
import time
import sqlite3 as db
import lcd_display

# Objekte instanzieren
x = classes.klima()

#		Zähler für while-Schleife (Auslesen des DHT)
#			Das ist notwendig, da der DHT oft falsche/keine Werte liefert
ok = 0
fail = 0


# 	DHT und BME auslesen.
while fail <= 10 and ok == 0:
	#print("Versuch ", fail+1, " von 10")
	fail += 1
	try:
		x.set_dht()
		x.set_bme_data()
		ok = 1
	except:
		#print("Fehler bei der Wertermittlung")
		pass

# Zur Entwicklung werden hier die angeforderten Werte ausgegeben.
#if ok == 1:
	#print(x.get_dht_hum(), " %rel.")
	#print(x.get_bme_pres(), " hPa")
	#print(x.get_bme_temp(), " C°  BME")
	#print(x.get_dht_temp(), " C°  DHT")
	#print(bl.balance()/1000, " Kilogramm")
	
# Rückmeldung, wenn DHT keine Werte liefert.
#elif ok != 1 and fail >= 10:
	#print("Fehler. Ist der Luftfeuchtesensor richtig angeschlossen?")
	
# Werte für Datenbankeinreichung ermitteln
timestamp = int(time.time())
weight    = bl.balance()/1000

# Datenbankaktion
conn = db.connect("/home/pi/py-code/Bee/data.sdb")
cursor = conn.cursor()

sql = "INSERT INTO mess "
sql = sql+"(messstelle, timestamp, dht_temp, dht_hum, bme_temp, bme_pres, weight) "
sql = sql+"VALUES(1 , "
sql = sql+str(timestamp)
sql = sql+", "+str(x.get_dht_temp())+", "+str(x.get_dht_hum())+", "+str(x.get_bme_temp())+", "+str(round(x.get_bme_pres(),6))+", "+str(weight)+")"
#print(sql)
cursor.execute(sql)
conn.commit()

conn.close()


# Werte an Display senden
	# obere Zeile
upper = str(weight)+" Kg"
lower = "T:"+str(x.get_dht_temp())+"C  H:"+str(x.get_dht_hum())+"%"
lcd_display.lcd(upper, lower)
