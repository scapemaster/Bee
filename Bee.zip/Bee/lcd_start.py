#!/usr/bin/python3

import lcd_display as lcd

try:
	lcd.lcd()
except:
	pass
