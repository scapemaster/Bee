#!/usr/bin/python3

import matplotlib as plt

daten = [1,2,6,5,8,7,1,5]
plt.plot(daten)
plt.show()
