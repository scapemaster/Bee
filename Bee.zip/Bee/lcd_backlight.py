#!/usr/bin/python3

#dfshhhhhhghfdghfghfghddddddddddddddddddd
#             Überarbeitung
#fhkjlgsfhgkjshdgdfjhkdfhgklfdjhgkljdfhgk




import RPi.GPIO as GPIO
import time
import pickle

config = {"lcd_backlight_pin": 22} #pickle.load(open("/home/pi/py-code/Bee/bee.conf", "rb"))
pin = config["lcd_backlight_pin"]

GPIO.setwarnings(False)

GPIO.setmode(GPIO.BCM)
GPIO.setup(pin, GPIO.OUT)

def lcd_on(freq=1, duration=3):
    if freq == "ever":
        GPIO.output(pin, GPIO.HIGH)
    elif freq == "never":
        GPIO.output(pin, GPIO.LOW)
    elif type(freq) != str:
        ts = 1/freq/2
        runs  = duration*freq
        
        ct = 1
        while ct <= runs:
            ct +=1
            time.sleep(ts)
            GPIO.output(pin, GPIO.HIGH)
            time.sleep(ts)
            GPIO.output(pin, GPIO.LOW)
