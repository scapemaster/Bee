class klima():
# ~~~~~~~~~ Initialisierung ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	def __init__(self):
		self.dht_temp = False
		self.dht_hum  = False
		self.bme_temp = False
		self.bme_pres = False
		self.bme_hum  = False # Ist nicht im Sensor enthalten
# ~~~~~~~~~~ DHT Luftfeuchte und Temperatursensor ~~~~~~~~~~~~~~

#	Dieser Sensor kann nur ca. alle 2 sec. angesprochen werden.

	# Lesen des DHT-Sensors
	def set_dht(self):
		import adafruit_dht
		import time
		import board
		
		time.sleep(2)
		dhtDevice = adafruit_dht.DHT22(board.D4, use_pulseio=False)
		
		self.dht_temp = dhtDevice.temperature
		self.dht_hum  = dhtDevice.humidity
	
	# Rückgabe der Luftfeuchte		
	def get_dht_hum(self):
		return self.dht_hum
		
	# Rückgabe der DHT-Temperatur
	def get_dht_temp(self):
		return self.dht_temp

# ~~~~~~~~~ BME 280 Luftdruck und Temperatursensor ~~~~~~~~~~~

	# Lesen des BME Sensor -Temperatur-
	def set_bme_data(self):
		import bme280
				
		self.bme_temp, self.bme_pres, self.bme_hum = bme280.get_bme_data()
		
	# Rückgabe der BME temperatur
	def get_bme_temp(self):
		return self.bme_temp
	# Rückgabe der BME temperatur
	def get_bme_pres(self):
		return self.bme_pres
	# Rückgabe der BME temperatur
	def get_bme_hum(self):
		return self.bme_hum
