#!/usr/bin/python3

import tkinter as tk
import classes
import time

main = tk.Tk()
main.title("Bee - Corrent Conditions")
fr_curr_cond 		= tk.Frame(main)
fr_curr_cond_val 		= tk.Frame(fr_curr_cond)
fr_curr_cond_sym 		= tk.Frame(fr_curr_cond)

curr_val_hum 				= tk.Label(fr_curr_cond_val)
curr_sym_hum				= tk.Label(fr_curr_cond_sym, text="%rel.")

curr_val_intemp				= tk.Label(fr_curr_cond_val)
curr_sym_intemp				= tk.Label(fr_curr_cond_sym, text="°C")

fr_curr_cond.pack()
fr_curr_cond_val.pack(side=tk.LEFT)
fr_curr_cond_sym.pack(side=tk.LEFT)
curr_val_hum.pack()
curr_sym_hum.pack()
curr_val_intemp.pack()
curr_sym_intemp.pack()


curr = classes.klima()
check = False
print("Beginn der Wertermittlung")
while check == False:
	try:
		curr.set_dht()
		curr_dht_temperatur = curr.get_dht_temp()
		curr_val_intemp.configure(text=str(curr_dht_temperatur))
		curr_dht_humidity   = curr.get_dht_hum()
		curr_val_hum.configure(text=str(curr_dht_humidity))
		check = True
		print("Done")
			
	except RuntimeError:
		print("Fail")
		pass
	except KeyboardInterrupt:
		print("Viel Spaß mit den Bienen! Bye!")


main.mainloop()
