#!/usr/bin/python3

# Module importieren
import sqlite3 as db
import time
import thingspeak

#Thingspeak API
chan_id = '1359826'
writekey= '2APLT60VHSBKB5T4'
channel = thingspeak.Channel(chan_id,writekey)

#Datensatz abfragen

conn   = db.connect("/home/pi/py-code/Bee/data.sdb")
cursor = conn.cursor()

sql = "SELECT * FROM mess WHERE timestamp = (SELECT max(timestamp) FROM mess)"

cursor.execute(sql)

for dsatz in cursor:
	stemp = dsatz[3] 
	shum  = dsatz[4]
	etemp = dsatz[5]
	press = dsatz[6]
	weight= dsatz[7]

conn.close()

# Datenuebertragung zu Thingspeak

response = channel.update({'field1':stemp, 'field2':shum, 'field3':etemp, 'field4':press, 'field5':weight})
