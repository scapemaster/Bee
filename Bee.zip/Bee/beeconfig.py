#!/usr/bin/python3

import pickle

config = pickle.load(open("bee.conf", "rb"))

# Testmodus
print("Inhalt der Config")
for i in config:
	print(i, " ==> ", config[i])

try:	
	print("Zum ändern eines Wertes geben sie desssen Namen an.")
	print("Andernfalls beenden sie das Programm mit [Strg+C].")
	
	while True:
		part = input("Name des Wertes: ")
		value = input("Wert: ")
		
		check = False
		msg   = "Kein Wert mit dem Namen: "+part+" vorhanden."
		for i in config:
			if str(i) == str(part):
				check = True
				msg = "Wert gespeichert"
			
		if check:
			old = config[part]
			config[part] = value
			pickle.dump(config,open("bee.conf", "wb"))
			print(part, ": ",old, " ==> ", config[part])
		# hier mit elif noch die frage nach neu-erstellung des wertes fragen.
		print(msg)
			

except KeyboardInterrupt:
	print("Bye")
