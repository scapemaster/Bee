#!/usr/bin/python3


#dfshhhhhhghfdghfghfghddddddddddddddddddd
#             Überarbeitung
#fhkjlgsfhgkjshdgdfjhkdfhgklfdjhgkljdfhgk


# Dieses Programm steuert das LCD Display an.

import lcddriver

def lcd(upperline="Bee.py", lowerline="Deine Stockwaage"):
	try:
		lcd = lcddriver.lcd()
		lcd.lcd_clear()

		lcd.lcd_display_string(upperline, 1)
		lcd.lcd_display_string(lowerline, 2)
	except:
		print("Display Error")
		pass
